#!/usr/bin/env bash
# =====================================================================
#  flow/sim/run.sh —— 跑一个 (方案 × 类别)
#
#  用法： bash flow/sim/run.sh <variant> <tag> <cat> <n> [seed] [verbose]
#  前件： build.sh 已经生成了 runs/<tag>/simv
#  产出： runs/<tag>/sim_<cat>.log   完整日志
#         runs/<tag>/summary.csv     追加一行（回归汇总用）
#
#  退出码：0=PASS，1=FAIL（make 会因此停下，这是故意的）
# =====================================================================
set -uo pipefail

VARIANT=${1:?用法: run.sh <variant> <tag> <cat> <n> [seed] [verbose]}
TAG=${2:?}
CAT=${3:?}
N=${4:?}
SEED=${5:-20260101}
VERBOSE=${6:-0}

RUN="runs/$TAG"
# SIMV_NAME 允许改名：另一条跑道上的清理动作常用 `pkill -f simv`，
# 名字一样就会被顺手杀掉（表现是某几类激励的日志是空的、结果莫名 FAIL）。
# 需要并行跑两条跑道时设成别的名字即可，默认行为完全不变。
SIMV="$RUN/${SIMV_NAME:-simv}"
# 向量目录与 genvec.sh 保持同一套命名规则：smoke 无后缀，full 带 _full
SUF=""
[ "${MODE:-smoke}" = "full" ] && SUF="_full"
VECDIR="tb/vectors/s$SEED$SUF"
LOG="$RUN/sim_$CAT.log"

if [ ! -x "$SIMV" ]; then
    echo "✗ 没有 $SIMV，先跑 build.sh"
    exit 1
fi
if [ ! -d "$VECDIR" ]; then
    echo "✗ 向量目录不存在: $VECDIR（先 make vec SEED=$SEED MODE=${MODE:-smoke}）"
    exit 1
fi

CM_OPTS=$(cat "$RUN/cm_opts.txt" 2>/dev/null || echo "")
CM_RUN=""
[ -n "$CM_OPTS" ] && CM_RUN="$CM_OPTS -cm_name ${VARIANT}_${TAG}_${CAT}"

# 数值格式标签由 make 从 config/variants.mk 传来，决定读哪个 _exp_<cfg>.hex。
# 这里不设默认值：默认值一旦和 RTL 的实际格式不一致，tb 会报"逐位全错"，
# 而这种假故障排查起来比真 bug 贵得多。
: "${CFGTAG:?未设置 CFGTAG —— 请用 make sim/regress 调用}"

echo "[run] $VARIANT/$CAT  n=$N  seed=$SEED  vec=$VECDIR  cfg=$CFGTAG"

# ⚠ 必须加 timeout。实测踩过一次：某一类激励让 DUT 卡在中间状态，tb 的
#   TIMEOUT=200000 拍兜底要跑满，而 -debug_access+all -kdb 下那 40 万拍能跑
#   二十分钟以上 —— 单类卡死就把整轮回归拖住，还占着 license。
#   正常一类 2~5 秒，给 300 秒是 60 倍余量；超了就是真有问题，判 FAIL。
SIM_TIMEOUT=${SIM_TIMEOUT:-300}
timeout -k 10 "$SIM_TIMEOUT" "$SIMV" \
    +VECDIR="$VECDIR" \
    +CFG="$CFGTAG" \
    +CAT="$CAT" \
    +N="$N" \
    +VERBOSE="$VERBOSE" \
    $CM_RUN \
    -l "$LOG" 2>&1 | tee "$LOG.stdout" | grep -vE '^$'
RC=${PIPESTATUS[0]}

# ---- DUT 握手断言：必须在这里判失败，不能只让 $error 打印 ----
# tb 的 status 只看 n_task_fail；$error 不会自动改 status。若不在这里拦截，
# 会出现“日志有 [VARB-B2C]、SUMMARY 仍 PASS、regress 退出 0”的假绿。
# 只匹配明确命名的 DUT 断言，避免把普通日志误判成失败。
ASSERT_HITS=$(grep -E '\[VARB-(B2C|A2B)\]' "$LOG" 2>/dev/null || true)
if [ -n "$ASSERT_HITS" ]; then
    ASSERT_COUNT=$(printf '%s\n' "$ASSERT_HITS" | wc -l | tr -d ' ')
    printf '%s\n' "$ASSERT_HITS" > "$RUN/assert_$CAT.log"
    printf '%s\n' "$ASSERT_HITS" | head -5
    echo "✗ DUT 握手断言触发（$ASSERT_COUNT 条）—— 这不是普通 log，判 FAIL"
    echo "$TAG,$VARIANT,$CAT,$N,0,$N,-1,-1,-1,0,0,0,FAIL,0" >> "$RUN/summary.csv"
    exit 1
fi

if [ "$RC" -eq 124 ] || [ "$RC" -eq 137 ]; then
    echo "✗ 仿真超时（${SIM_TIMEOUT}s）—— DUT 大概率卡在中间状态没回到 S_IDLE。"
    echo "  看 $LOG 末尾；这类问题不会自己好，别重跑碰运气。"
    echo "$TAG,$VARIANT,$CAT,$N,0,$N,-1,-1,-1,-1,-1,-1,TIMEOUT,0" >> "$RUN/summary.csv"
    exit 1
fi

# ---- 准备阶段异常（向量缺失、文件不完整）先单独报，别混进 PASS/FAIL 统计 ----
if grep -q '^\[FATAL\]' "$LOG" 2>/dev/null; then
    grep -m3 '^\[FATAL\]' "$LOG"
    echo "✗ 仿真在准备阶段就退出了（向量或环境问题，不是 RTL 的问题）"
    exit 1
fi

# ---- 从机器可读汇总行提取指标 ----
LINE=$(grep -m1 '^\[SUMMARY\]' "$LOG" 2>/dev/null || true)
if [ -z "$LINE" ]; then
    echo "✗ 日志里没有 [SUMMARY] 行，仿真可能在启动阶段就崩了。看 $LOG"
    tail -20 "$LOG" 2>/dev/null
    exit 1
fi

get() { echo "$LINE" | sed -n "s/.*[ ]$1=\([^ ]*\).*/\1/p"; }

TASKS=$(get tasks); PASS=$(get pass); FAIL=$(get fail)
LMIN=$(get lat_min); LAVG=$(get lat_avg); LMAX=$(get lat_max)
RMSE=$(get rmse); MAXAE=$(get maxae); MIS=$(get mism); STATUS=$(get status)
# 方案 A：装载拍数由 tb 实测上报（老版本 tb 没有 ld= 字段，此时记 0）。
LD=$(get ld); [ -n "$LD" ] || LD=0

echo "$TAG,$VARIANT,$CAT,$TASKS,$PASS,$FAIL,$LMIN,$LAVG,$LMAX,$RMSE,$MAXAE,$MIS,$STATUS,$LD" \
    >> "$RUN/summary.csv"

printf "[run] %-8s %-12s %s  (pass %s/%s, lat %s/%s/%s, ld %s, rmse %s, max|e| %s, mism %s)\n" \
    "$VARIANT" "$CAT" "$STATUS" "$PASS" "$TASKS" "$LMIN" "$LAVG" "$LMAX" "$LD" "$RMSE" "$MAXAE" "$MIS"

[ "$STATUS" = "PASS" ] || exit 1
exit 0
